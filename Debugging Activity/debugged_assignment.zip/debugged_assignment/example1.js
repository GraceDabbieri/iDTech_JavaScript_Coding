function checkPoint1() {
//alert1();
let array = [];
let x = 5;
    function getMultiples() {
        while (x >= 1){
            array.push(x);
x = x -1
        }
        return array;
    }
    console.log(getMultiples()); 

    // DO NOT CHANGE THE CODE BELOW
    alert2();
}


/************************************************ DONT CHANGE THE CODE BELOW ******************************************************/
function alert1() {
    alert("Oh no! It looks like you are trapped in an infinite loop. Go to the example1.js file and work on checkpoint 1.");
}

function alert2(){
    alert("Congratulations! You have passed checkpoint 1!");
}